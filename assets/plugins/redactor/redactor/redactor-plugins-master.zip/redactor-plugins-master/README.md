Redactor Plugins
================
[http://imperavi.com/redactor/](http://imperavi.com/redactor/)

Collection of plugins developed for Redactor, a WYSIWYG rich-text editor made by [@imperavi](http://twitter.com/imperavi).

Feel free to contribute to this repository.

* clean_text.js - Removes formatting from selected text
* fontcolor.js - Sets the text color and text background color
* fontfamily.js - Changes the font family
* fontsize.js - Changes the font size specified in pixels
* blockquotebreak.js - Redactor plugin to break blockquote like gmail
* fullscreen.js - The "fullscreen" mode is now a plugin on the toolbar to toggle full-window editing on and off
* emoticon.js - An emoticon plugin for Redactor WYSIWYG editor
